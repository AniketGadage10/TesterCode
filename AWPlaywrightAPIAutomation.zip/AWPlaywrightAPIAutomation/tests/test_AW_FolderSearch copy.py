﻿import pytest

from utilities.logger import getlogger
from utilities.random_utils import generate_random_number

logger = getlogger(
    "AW_FolderSearch",
    log_file="AW_FolderSearch.log",
)


@pytest.mark.regression
@pytest.mark.requires_server
def test_AW_FolderSearch(api_services) -> None:
    logger.info("Starting test: AW_FolderSearch")

    username = api_services.test_user.get("username", "")

    logger.info("----------------------------------------------")
    logger.info("Step 1: Logging in with user '%s'", username)
    logger.info("----------------------------------------------")

    login_response = api_services.login_service.login()

    try:
        assert login_response.is_success, f"Login failed with status {login_response.status}: {login_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 1 failed: Login failed for user '%s'.", username)
        logger.warning("Step 1 failed: Login failed with message: %s.", exception)
        raise

    logger.info("Step 1 passed: Login succeeded for user '%s'.", username)

    logger.info("----------------------------------------------")
    logger.info("Step 2: Creating folder in AWC")
    logger.info("----------------------------------------------")

    folder_name = f"AUT_TEST_{generate_random_number()}"

    response = api_services.folder_service.create_folder(folder_name)

    try:
        assert response.is_success, f"Folder creation failed with status {response.status}: {response.text()}"
    except AssertionError as exception:
        logger.warning("Step 2 failed: Folder creation failed with status %s.", response.status)
        logger.warning("Step 2 failed: Folder creation failed with message: %s.", exception)
        raise

    logger.info("Step 2 passed: Folder [%s] creation request completed successfully", folder_name)

    logger.info("----------------------------------------------")
    logger.info("Step 3: Verifying folder via search in AWC")
    logger.info("----------------------------------------------")

    search_response = api_services.folder_service.search_folder(folder_name)
    try:
        assert search_response.is_success, f"Folder search failed with status {search_response.status}: {search_response.text()}"
        logger.info("Step 3 passed: Folder search completed successfully for [%s]", folder_name)

        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 1, (
            f"Expected exactly one folder matching [{folder_name}], "
            f"but found {total_found}. Response status: {search_response.status}. "
            f"Response: {search_response.text()}"
        )
        logger.info("Step 3 passed: Successfully verified that exactly one search result found for folder [%s]", folder_name)
    except AssertionError as exception:
        logger.warning("Step 3 failed: Folder search failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Folder search failed with message: %s.", exception)
        raise
    

    logger.info("----------------------------------------------")
    logger.info("Step 4: Logging out from AWC")
    logger.info("----------------------------------------------")

    logout_response = api_services.logout_service.logout()
    try:
        assert logout_response.status == 200, f"Logout failed with status {logout_response.status}"
    except AssertionError as exception:
        logger.warning("Step 4 failed: Logout failed with status %s.", logout_response.status)
        logger.warning("Step 4 failed: Logout failed with message: %s.", exception)
        raise

    logger.info("Step 4 passed: Logout completed successfully")
    logger.info("Test completed successfully: AW_FolderSearch")
