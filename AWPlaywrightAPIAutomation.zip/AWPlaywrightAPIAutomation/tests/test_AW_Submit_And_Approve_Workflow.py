import pytest

from utilities.logger import getlogger
from utilities.random_utils import generate_random_number

logger = getlogger(
    "AW_Submit_And_Approve_Workflow",
    log_file="AW_Submit_And_Approve_Workflow.log",
)

WORKFLOW_TEMPLATE = "ChangeItemRevisionDefaultWorkflowTemplate"
WORKFLOW_NAME = f"AUT_TEST_Workflow({WORKFLOW_TEMPLATE})_{generate_random_number()}"


@pytest.mark.regression
@pytest.mark.requires_server
def test_AW_Submit_And_Approve_Workflow(api_services) -> None:
    logger.info("Starting test: AW_Submit_And_Approve_Workflow")

    username = api_services.test_user.get("username", "")

    logger.info("----------------------------------------------")
    logger.info("Step 1: Logging in with user '%s'", username)
    logger.info("----------------------------------------------")

    try:
        login_response = api_services.login_service.login()
        
        assert login_response.is_success, f"Login failed with status {login_response.status}: {login_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 1 failed: Login failed for user '%s'.", username)
        logger.warning("Step 1 failed: Login failed with message: %s.", exception)
        raise

    logger.info("Step 1 passed: Login succeeded for user '%s'.", username)

    logger.info("----------------------------------------------")
    logger.info("Step 2: Creating item in AWC")
    logger.info("----------------------------------------------")

    item_name = f"AUT_TEST_ITEM_{generate_random_number()}"

    try:
        response = api_services.item_service.create_item(item_name)
        assert response.is_success, f"Item creation failed with status {response.status}: {response.text()}"
    except AssertionError as exception:
        logger.warning("Step 2 failed: Item creation failed with status %s.", response.status)
        logger.warning("Step 2 failed: Item creation failed with message: %s.", exception)
        raise

    response_json = response.json()
    
    item_revision_uid = next(
        obj["uid"]
        for obj in response_json["output"][0]["objects"]
        if obj["className"] == "ItemRevision"
    )
    
    logger.info("Step 2 passed: Item [%s] creation request completed successfully", item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 3: Verifying item via search in AWC")
    logger.info("----------------------------------------------")

    
    try:
        search_response = api_services.item_service.search_item(item_name)

        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 1, (
            f"Expected exactly one item matching [{item_name}], "
            f"but found {total_found}. Response status: {search_response.status}. "
            f"Response: {search_response.text()}"
        )
        logger.info("Step 3 passed: Successfully verified that exactly one item found for [%s]", item_name)
    except AssertionError as exception:
        logger.warning("Step 3 failed: Item search failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Item search failed with message: %s.", exception)
        raise

    try:
        assert search_response.is_success, f"Item verification failed with status {search_response.status}: {search_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 3 failed: Item verification failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Item verification failed with message: %s.", exception)
        raise

    logger.info("Step 3 passed: Item [%s] verified successfully via search", item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 4: Applying workflow to item [%s] in AWC", item_name)
    logger.info("----------------------------------------------")
    
    try:
        workflow_response = api_services.workflow_service.create_workflow(
            item_revision_uid=item_revision_uid,
            workflow_template=WORKFLOW_TEMPLATE,
            workflow_name=WORKFLOW_NAME
        )
        
        assert workflow_response.is_success, f"Workflow creation failed with status {workflow_response.status}: {workflow_response.text()}" 
    except AssertionError as exception:
        logger.warning("Step 4 failed: Workflow creation failed with status %s.", workflow_response.status)
        logger.warning("Step 4 failed: Workflow creation failed with message: %s.", exception)
        raise  

    response = workflow_response.json()  # Ensure the response is parsed as JSON

    model_objects = response["ServiceData"]["modelObjects"]

    task_id = next(
        (
            obj["objectID"]
            for obj in model_objects.values()
            if obj.get("type") == "EPMDoTask"
        ),
        None
    )

    if task_id is None:
        logger.warning("Step 4 failed: No EPMDoTask object found in workflow creation response.")
        raise RuntimeError("No EPMDoTask object found in workflow creation response.")
    
    logger.info("Step 4 passed: Workflow [%s] creation request completed successfully for item [%s]", WORKFLOW_NAME, item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 5: Approving workflow task [%s] for item [%s] in AWC", task_id, item_name)
    logger.info("----------------------------------------------")

    try:
        approve_response = api_services.workflow_service.approve_workflow_task(task_id)
        assert approve_response.is_success, f"Workflow task approval failed with status {approve_response.status}: {approve_response.text()}"   
    except AssertionError as exception:
        logger.warning("Step 5 failed: Workflow task approval failed with status %s.", approve_response.status)
        logger.warning("Step 5 failed: Workflow task approval failed with message: %s.", exception)
        raise

    logger.info("Step 5 passed: Workflow [%s] EPMDoTask [%s] for item [%s] was approved successfully.",WORKFLOW_NAME,task_id,item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 6: Logging out from AWC")
    logger.info("----------------------------------------------")
 
    try:
        logout_response = api_services.logout_service.logout()
        
        assert logout_response.status == 200, f"Logout failed with status {logout_response.status}"
    except AssertionError as exception:
        logger.warning("Step 6 failed: Logout failed with status %s.", logout_response.status)
        logger.warning("Step 6 failed: Logout failed with message: %s.", exception)
        raise

    logger.info("Step 6 passed: Logout completed successfully")
    logger.info("Test completed successfully: AW_Submit_And_Approve_Workflow")
