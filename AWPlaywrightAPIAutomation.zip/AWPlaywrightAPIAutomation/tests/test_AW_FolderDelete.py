﻿import pytest

from utilities.logger import getlogger
from utilities.random_utils import generate_random_number

logger = getlogger(
    "AW_FolderDelete",
    log_file="AW_FolderDelete.log",
)

@pytest.mark.regression
@pytest.mark.requires_server
def test_AW_FolderDelete(api_services) -> None:
    logger.info("Starting test: AW_FolderDelete")
    username = api_services.test_user.get("username", "")

    logger.info("----------------------------------------------")
    logger.info("Step 1: Logging in with user '%s'", username)
    logger.info("----------------------------------------------")

    login_response = api_services.login_service.login()
    try:
        assert login_response.is_success, f"Login failed with status {login_response.status}: {login_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 1 failed: Login failed for user '%s'.", username)
        logger.warning("Step 1 failed: Login failed with message: %s.", exception)
        raise

    logger.info("Step 1 passed: Login succeeded for user '%s'.", username)

    logger.info("----------------------------------------------")
    logger.info("Step 2: Creating folder in AWC")
    logger.info("----------------------------------------------")
    
    folder_name = f"AUT_TEST_{generate_random_number()}"
    response = api_services.folder_service.create_folder(folder_name)
    try:
        assert response.is_success, f"Folder creation failed with status {response.status}: {response.text()}"

        response_payload = response.json()
        service_data = response_payload.get("ServiceData", {})
        created_uids = service_data.get("created", [])
        folder_uid = created_uids[0] if created_uids else ""
        if not folder_uid:
            folder_uid = response_payload.get("output", [{}])[0].get("objects", [{}])[0].get("uid", "")
        assert isinstance(folder_uid, str) and folder_uid.strip(), (
            f"Created folder UID is missing from response: {response.text()}"
        )
    except (AssertionError, AttributeError, IndexError, KeyError, TypeError) as exception:
        logger.warning("Step 2 failed: Folder creation or UID extraction failed with status %s.", response.status)
        logger.warning("Step 2 failed: Folder creation message: %s.", exception)
        raise

    logger.info("Folder [%s] created with UID [%s]", folder_name, folder_uid)

    logger.info("----------------------------------------------")
    logger.info("Step 3: Verifying folder created via search in AWC")
    logger.info("----------------------------------------------")

    search_response = api_services.folder_service.search_folder(folder_name)
    try:
        assert search_response.is_success, f"Folder search failed with status {search_response.status}: {search_response.text()}"
        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 1, (
            f"Expected exactly one folder matching [{folder_name}], but found {total_found}. "
            f"Response: {search_response.text()}"
        )
    except (AssertionError, AttributeError, TypeError) as exception:
        logger.warning("Step 3 failed: Folder search failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Folder search message: %s.", exception)
        raise

    logger.info("Step 3 passed: Folder [%s] verified successfully", folder_name)
    logger.info("Step 3 passed: Successfully verified that exactly one folder found for [%s]", folder_name)

    logger.info("----------------------------------------------")
    logger.info("Step 4: Deleting Folder created in AWC")
    logger.info("----------------------------------------------")

    delete_response = api_services.folder_service.delete_folder(folder_uid)
    try:
        assert delete_response.is_success, (
            f"Folder deletion failed with status {delete_response.status}: {delete_response.text()}"
        )
    except AssertionError as exception:
        logger.warning("Step 4 failed: Folder deletion failed with status %s.", delete_response.status)
        logger.warning("Step 4 failed: Folder deletion message: %s.", exception)
        raise

    logger.info("Folder [%s] deleted successfully", folder_uid)

    logger.info("----------------------------------------------")
    logger.info("Step 5: Verifying folder deleted via search in AWC")
    logger.info("----------------------------------------------")

    search_response = api_services.folder_service.search_folder(folder_name)
    try:
        assert search_response.is_success, f"Folder search failed with status {search_response.status}: {search_response.text()}"
        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 0, (
            f"Expected no folders matching [{folder_name}], but found {total_found}. "
            f"Response: {search_response.text()}"
        )
    except (AssertionError, AttributeError, TypeError) as exception:
        logger.warning("Step 5 failed: Folder search failed with status %s.", search_response.status)
        logger.warning("Step 5 failed: Folder search message: %s.", exception)
        raise

    logger.info("Step 5 passed: Successfully verified that no folders found for [%s]", folder_name)

    logger.info("----------------------------------------------")
    logger.info("Step 6: Logging out from AWC")
    logger.info("----------------------------------------------")

    logout_response = api_services.logout_service.logout()
    try:
        assert logout_response.status == 200, f"Logout failed with status {logout_response.status}"
    except AssertionError as exception:
        logger.warning("Step 6 failed: Logout failed with status %s.", logout_response.status)
        logger.warning("Step 6 failed: Logout message: %s.", exception)
        raise

    logger.info("Step 6 passed: Logout completed successfully")
    logger.info("Test completed successfully: AW_FolderDelete")

