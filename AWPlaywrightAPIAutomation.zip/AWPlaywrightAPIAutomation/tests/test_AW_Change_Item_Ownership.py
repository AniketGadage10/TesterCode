from sys import exception

import pytest

from core.exceptions import ResponseValidationError
from utilities.logger import getlogger
from utilities.random_utils import generate_random_number

logger = getlogger(
    "AW_Change_Item_Ownership",
    log_file="AW_Change_Item_Ownership.log",
)


@pytest.mark.regression
@pytest.mark.requires_server
def test_change_item_ownership(api_services) -> None:
    logger.info("Starting test: Change Item Ownership")

    username = api_services.test_user.get("username", "")

    logger.info("----------------------------------------------")
    logger.info("Step 1: Logging in with user '%s'", username)
    logger.info("----------------------------------------------")

    login_response = api_services.login_service.login()

    try:
        assert login_response.is_success, f"Login failed with status {login_response.status}: {login_response.text()}"
    except AssertionError:
        logger.warning(
            "Step 1 failed: Login failed for user '%s'. Status=%s. Body=%s",
            username,
            getattr(login_response, "status", None),
            login_response.text(),
        )
        raise

    logger.info("Step 1 passed: Login succeeded for user '%s'.", username)

    logger.info("----------------------------------------------")
    logger.info("Step 2: Creating item in AWC")
    logger.info("----------------------------------------------")

    item_name = f"AUT_TEST_ITEM_{generate_random_number()}"

    response = api_services.item_service.create_item(item_name)

    try:
        assert response.is_success, f"Item creation failed with status {response.status}: {response.text()}"
    except AssertionError as exception:
        logger.warning("Step 2 failed: Item creation failed with status %s.", response.status)
        logger.warning("Step 2 failed: Item creation failed with message: %s.", exception)
        raise

    response_json = response.json()

    item_uid = next(
        obj["uid"]
        for obj in response_json["output"][0]["objects"]
        if obj["className"] == "Item"
    )

    logger.info("Step 2 passed: Item [%s] creation request completed successfully", item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 3: Verifying item via search in AWC")
    logger.info("----------------------------------------------")

    search_response = api_services.item_service.search_item(item_name)
    
    try:
        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 1, (
            f"Expected exactly one item matching [{item_name}], "
            f"but found {total_found}. Response status: {search_response.status}. "
            f"Response: {search_response.text()}"
        )
        logger.info("Step 3 passed: Successfully verified that exactly one item found for [%s]", item_name)
    except AssertionError as exception:
        logger.warning("Step 3 failed: Item search failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Item search failed with message: %s.", exception)
        raise

    try:
        assert search_response.is_success, f"Item verification failed with status {search_response.status}: {search_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 3 failed: Item verification failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Item verification failed with message: %s.", exception)
        raise

    logger.info("Step 3 passed: Item [%s] verified successfully via search", item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 4: Changing ownership of item [%s] in AWC to user infodba", item_name)
    logger.info("----------------------------------------------")

    change_ownership_response = api_services.common_service.change_item_ownership(item_uid)
    try:
        assert change_ownership_response.is_success, (
            f"Change item ownership failed with status "
            f"{change_ownership_response.status}: "
            f"{change_ownership_response.text()}"
        )
    except AssertionError as exception:
        logger.warning(
            "Step 4 failed: Change item ownership failed with status %s.",
            change_ownership_response.status
        )
        logger.warning(
            "Step 4 failed: Change item ownership failed with message: %s.",
            exception
        )
        raise

    # Get response JSON
    response = change_ownership_response.json()

    try:
        item = response["modelObjects"][item_uid]
        assert item["className"] == "Item", (
            f"Expected ownership response for Item UID '{item_uid}', "
            f"but got '{item.get('className')}'"
        )

        owning_user = item["props"]["owning_user"]["uiValues"][0]

        assert owning_user == "infodba (infodba)", (
            f"Expected owning user 'infodba (infodba)', "
            f"but got '{owning_user}'"
        )

    except AssertionError as exception:
        logger.warning(
            "Step 4 failed: Owning user verification failed."
        )
        logger.warning(
            "Step 4 failed: %s",
            exception
        )
        raise 
    
    logger.info("Step 4 passed: Ownership of item [%s] was successfully changed to infodba (infodba).",item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 5: Logging out from AWC")
    logger.info("----------------------------------------------")

    logout_response = api_services.logout_service.logout()
    try:
        assert logout_response.status == 200, f"Logout failed with status {logout_response.status}"
    except AssertionError:
        logger.warning("Step 5 failed: Logout failed with status %s.", logout_response.status)
        raise

    logger.info("Step 5 passed: Logout completed successfully")
    logger.info("Test completed successfully: Change Item Ownership")
    
