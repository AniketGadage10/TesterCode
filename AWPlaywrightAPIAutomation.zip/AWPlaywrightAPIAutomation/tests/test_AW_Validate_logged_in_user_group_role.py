import pytest

from core.exceptions import ResponseValidationError
from utilities.logger import getlogger

logger = getlogger(
    "AW_validate_logged_in_user_group_role",
    log_file="AW_validate_logged_in_user_group_role.log",
)


@pytest.mark.regression
@pytest.mark.requires_server
def test_validate_logged_in_user_group_role(api_services) -> None:
    logger.info("Starting test: Validate Logged In User Group Role")

    username = api_services.test_user.get("username", "")
    password = api_services.test_user.get("password", "")
    group = api_services.test_user.get("group", "")
    role = api_services.test_user.get("role", "")
    locale = api_services.test_user.get("locale", "en_US")

    logger.info("----------------------------------------------")
    logger.info("Step 1: Logging in with user '%s'", username)
    logger.info("Step 1: Resolved login values -> user=%s group=%s role=%s locale=%s", username, group, role, locale)
    logger.info("----------------------------------------------")

    login_response = api_services.login_service.login()

    try:
        assert login_response.is_success, f"Login failed with status {login_response.status}: {login_response.text()}"
    except AssertionError:
        logger.warning(
            "Step 1 failed: Login failed for user '%s'. Status=%s. Body=%s",
            username,
            getattr(login_response, "status", None),
            login_response.text(),
        )
        raise

    logger.info("Step 1 passed: Login succeeded for user '%s'.", username)

    expected_user = api_services.test_user.get("username")
    expected_group = api_services.test_user.get("group")
    expected_role = api_services.test_user.get("role")

    logger.info("----------------------------------------------")
    logger.info("Step 2: Fetching session information")
    logger.info("----------------------------------------------")

    response = api_services.session_info_service.get_session_info()
    try:
        assert response.status == 200, f"Session verification failed with status {response.status}"
    except AssertionError:
        logger.warning("Step 2 failed: Session verification failed with status %s.", response.status)
        raise

    logger.info("Step 2 passed: Session information retrieved successfully")

    try:
        payload = response.json()
    except Exception as exc:
        logger.exception("Step 2 failed: Unable to parse session info response JSON.")
        raise ResponseValidationError("Unable to parse session info response JSON.") from exc

    user_session_uid = api_services.session_info_service.find_user_session(payload)
  
    actual_user, actual_group, actual_role = api_services.session_info_service.extract_session_properties(payload, user_session_uid)
    try:
        assert actual_user == expected_user, f"Expected User {expected_user} but received {actual_user}."
        logger.info("Step 2 passed: User validation successful - '%s'", actual_user)

        assert actual_group == expected_group, f"Expected Group {expected_group} but received {actual_group}."
        logger.info("Step 2 passed: Group validation successful - '%s'", actual_group)

        assert actual_role == expected_role, f"Expected Role {expected_role} but received {actual_role}."
        logger.info("Step 2 passed: Role validation successful - '%s'", actual_role)
    except AssertionError as exc:
        logger.warning("Step 2 failed: Validation mismatch - %s", exc)
        raise

    logger.info("Step 2 passed: Session validation completed successfully")

    logger.info("----------------------------------------------")
    logger.info("Step 3: Logging out from AWC")
    logger.info("----------------------------------------------")

    logout_response = api_services.logout_service.logout()
    try:
        assert logout_response.status == 200, f"Logout failed with status {logout_response.status}"
    except AssertionError:
        logger.warning("Step 3 failed: Logout failed with status %s.", logout_response.status)
        raise

    logger.info("Step 3 passed: Logout completed successfully")
    logger.info("Test completed successfully: Validate Logged In User Group Role")
    
