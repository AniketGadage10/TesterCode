﻿import pytest

from utilities.logger import getlogger
from utilities.random_utils import generate_random_number

logger = getlogger(
    "AW_Cut_Created_Object_Under_Folder",
    log_file="AW_Cut_Created_Object_Under_Folder.log",
)

@pytest.mark.regression
@pytest.mark.requires_server
def test_AW_Cut_Created_Object_Under_Folder(api_services) -> None:
    logger.info("Starting test: AW_Cut_Created_Object_Under_Folder")

    username = api_services.test_user.get("username", "")

    logger.info("----------------------------------------------")
    logger.info("Step 1: Logging in with user '%s'", username)
    logger.info("----------------------------------------------")

    login_response = api_services.login_service.login()
    
    try:
        assert login_response.is_success, f"Login failed with status {login_response.status}: {login_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 1 failed: Login failed for user '%s'.", username)
        logger.warning("Step 1 failed: Login failed with message: %s.", exception)
        raise

    logger.info("Step 1 passed: Login succeeded for user '%s'.", username)

    logger.info("----------------------------------------------")
    logger.info("Step 2: Creating folder in AWC")
    logger.info("----------------------------------------------")
    
    folder_name = f"AUT_TEST_{generate_random_number()}"
    response = api_services.folder_service.create_folder(folder_name)
    try:
        assert response.is_success, f"Folder creation failed with status {response.status}: {response.text()}"

        response_payload = response.json()
        service_data = response_payload.get("ServiceData", {})
        created_uids = service_data.get("created", [])
        folder_uid = created_uids[0] if created_uids else ""
        if not folder_uid:
            folder_uid = response_payload.get("output", [{}])[0].get("objects", [{}])[0].get("uid", "")
        assert isinstance(folder_uid, str) and folder_uid.strip(), (
            f"Created folder UID is missing from response: {response.text()}"
        )
    except (AssertionError, AttributeError, IndexError, KeyError, TypeError) as exception:
        logger.warning("Step 2 failed: Folder creation or UID extraction failed with status %s.", response.status)
        logger.warning("Step 2 failed: Folder creation message: %s.", exception)
        raise

    logger.info("Folder [%s] created with UID [%s]", folder_name, folder_uid)

    logger.info("----------------------------------------------")
    logger.info("Step 3: Verifying folder created via search in AWC")
    logger.info("----------------------------------------------")

    search_response = api_services.folder_service.search_folder(folder_name)
    try:
        assert search_response.is_success, f"Folder search failed with status {search_response.status}: {search_response.text()}"
        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 1, (
            f"Expected exactly one folder matching [{folder_name}], but found {total_found}. "
            f"Response: {search_response.text()}"
        )
    except (AssertionError, AttributeError, TypeError) as exception:
        logger.warning("Step 3 failed: Folder search failed with status %s.", search_response.status)
        logger.warning("Step 3 failed: Folder search message: %s.", exception)
        raise

    logger.info("Step 3 passed: Folder [%s] verified successfully", folder_name)
    logger.info("Step 3 passed: Successfully verified that exactly one folder found for [%s]", folder_name)

    logger.info("----------------------------------------------")
    logger.info("Step 4: Creating item in AWC")
    logger.info("----------------------------------------------")
    
    item_name = f"AUT_TEST_ITEM_{generate_random_number()}"

    response = api_services.item_service.create_item(item_name)

    try:
        assert response.is_success, f"Item creation failed with status {response.status}: {response.text()}"

        response_payload = response.json()
        service_data = response_payload.get("ServiceData", {})
        created_uids = service_data.get("created", [])
        item_uid = created_uids[0] if created_uids else ""
        if not item_uid:
            item_uid = response_payload.get("output", [{}])[0].get("objects", [{}])[0].get("uid", "")
        assert isinstance(item_uid, str) and item_uid.strip(), (
            f"Created item UID is missing from response: {response.text()}"
        )

    except AssertionError as exception:
        logger.warning("Step 4 failed: Item creation failed with status %s.", response.status)
        logger.warning("Step 4 failed: Item creation failed with message: %s.", exception)
        raise

    logger.info("Step 4 passed: Item [%s] creation request completed successfully", item_name)

    logger.info("----------------------------------------------")
    logger.info("Step 5: Verifying item via search in AWC")
    logger.info("----------------------------------------------")

    search_response = api_services.item_service.search_item(item_name)
    
    try:
        total_found = search_response.json().get("totalFound", 0)
        assert total_found == 1, (
            f"Expected exactly one item matching [{item_name}], "
            f"but found {total_found}. Response status: {search_response.status}. "
            f"Response: {search_response.text()}"
        )
        logger.info("Step 5 passed: Successfully verified that exactly one item found for [%s]", item_name)
    except AssertionError as exception:
        logger.warning("Step 5 failed: Item search failed with status %s.", search_response.status)
        logger.warning("Step 5 failed: Item search failed with message: %s.", exception)
        raise

    try:
        assert search_response.is_success, f"Item verification failed with status {search_response.status}: {search_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 5 failed: Item verification failed with status %s.", search_response.status)
        logger.warning("Step 5 failed: Item verification failed with message: %s.", exception)
        raise

    logger.info("Step 5 passed: Item [%s] verified successfully via search", item_name)


    logger.info("----------------------------------------------")
    logger.info("Step 6: Copying item [%s] to folder [%s] in AWC", item_name, folder_name)
    logger.info("----------------------------------------------")

    copy_response = api_services.item_service.create_item_relations(folder_uid, item_uid, "contains")
    try:   
        assert copy_response.is_success, f"Item copy failed with status {copy_response.status}: {copy_response.text()}"
        assert item_uid in copy_response.text(), f"Item copy response does not contain the expected item UID {item_uid}: {copy_response.text()}"
        assert folder_uid in copy_response.text(), f"Item copy response does not contain the expected folder UID {folder_uid}: {copy_response.text()}"
    except AssertionError as exception: 
        logger.warning("Step 6 failed: Item copy failed with status %s.", copy_response.status)
        logger.warning("Step 6 failed: Item copy failed with message: %s.", exception)
        raise

    logger.info("Step 6 passed: Item [%s] copied to folder [%s] successfully", item_name, folder_name)

    logger.info("----------------------------------------------")
    logger.info("Step 7: Cutting item [%s] from folder [%s] in AWC", item_name, folder_name)
    logger.info("----------------------------------------------")

    cut_response = api_services.item_service.cut_item_from_folder(folder_uid, item_uid)

    try:
        assert cut_response.is_success, f"Item cut failed with status {cut_response.status}: {cut_response.text()}"
        assert item_uid not in cut_response.text(), f"Item cut response still contains the item UID {item_uid}: {cut_response.text()}"
        assert folder_uid in cut_response.text(), f"Item cut response does not contain the expected folder UID {folder_uid}: {cut_response.text()}"
    except AssertionError as exception:
        logger.warning("Step 7 failed: Item cut failed with status %s.", cut_response.status)
        logger.warning("Step 7 failed: Item cut failed with message: %s.", exception)
        raise  
    logger.info("Step 7 passed: Item [%s] cut from folder [%s] successfully", item_name, folder_name)
    
    logger.info("----------------------------------------------")
    logger.info("Step 8: Logging out from AWC")
    logger.info("----------------------------------------------")

    logout_response = api_services.logout_service.logout()
    try:
        assert logout_response.status == 200, f"Logout failed with status {logout_response.status}"
    except AssertionError as exception:
        logger.warning("Step 8 failed: Logout failed with status %s.", logout_response.status)
        logger.warning("Step 8 failed: Logout failed with message: %s.", exception)
        raise

    logger.info("Step 8 passed: Logout completed successfully")
    logger.info("Test completed successfully: AW_Cut_Created_Object_Under_Folder")
