from __future__ import annotations

from core.base_service import BaseService
from models.api_response import ApiResponse
from utilities.payload_loader import load_payload

PIN_TO_HOME_ENDPOINT = "/tc/RestServices/Internal-AWS2-2018-05-DataManagement/pinObjects"
GO_TO_HOME_ENDPOINT = "/tc/RestServices/Internal-AWS2-2022-12-DataManagement/getCurrentUserGateway3"
ADD_TO_FAVORITES_ENDPOINT = "/tc/RestServices/Internal-AWS2-2019-06-DataManagement/modifyFavorites"
CHANGE_ITEM_OWNERSHIP_ENDPOINT = "/tc/RestServices/Core-2023-12-DataManagement/changeOwner2"

class CommonService(BaseService):
    """Service for common operations."""

    service_name = "common-service"

    def pin_to_home(self, folder_uid: str) -> ApiResponse:
        payload = load_payload(
            "pin_to_home_payload",
            values={"folder_uid": folder_uid},
            client_config=self.client_config,
        )
        return self.api_client.request("POST", PIN_TO_HOME_ENDPOINT, payload=payload)

    def go_to_home(self) -> ApiResponse:
        payload = load_payload("go_to_home_payload", client_config=self.client_config)
        return self.api_client.request("POST", GO_TO_HOME_ENDPOINT, payload=payload)    

    def add_to_favorites(self, item_revision_uid: str) -> ApiResponse:
        payload = load_payload(
            "add_to_favorites_payload",
            values={"item_revision_uid": item_revision_uid},
            client_config=self.client_config,
        )
        return self.api_client.request("POST", ADD_TO_FAVORITES_ENDPOINT, payload=payload)

    def change_item_ownership(self, item_uid: str) -> ApiResponse:
        payload = load_payload(
            "change_item_ownership_payload",
            values={"item_uid": item_uid},
            client_config=self.client_config,
        )
        print(f"Payload for change_item_ownership: {payload}")  # Debugging line
        return self.api_client.request("POST", CHANGE_ITEM_OWNERSHIP_ENDPOINT, payload=payload)