from __future__ import annotations

from core.base_service import BaseService
from models.api_response import ApiResponse
from utilities.payload_loader import load_payload

ITEM_CREATION_ENDPOINT = "/tc/RestServices/Core-2016-09-DataManagement/createAttachAndSubmitObjects"
ITEM_SEARCH_ENDPOINT = "/tc/RestServices/Internal-AWS2-2025-06-Finder/performSearchViewModel6"
ITEM_CREATE_RELATIONS_ENDPOINT = "/tc/RestServices/Core-2006-03-DataManagement/createRelations"
ITEM_REMOVE_CHILDREN_ENDPOINT = "/tc/RestServices/Core-2014-10-DataManagement/removeChildren"

class ItemService(BaseService):
    """Service for creating and searching items through AWC SOA endpoints."""

    service_name = "item-service"

    def create_item(self, item_name: str, target_uid: str = "AAAAAAAAAAAAAA", target_type: str = "unknownType") -> ApiResponse:
        payload = load_payload(
            "item_creation_payload",
            values={
                "item_name": item_name,
                "target_uid": target_uid,
                "target_type": target_type,
            },
            client_config=self.client_config,
        )
        return self.api_client.request("POST", ITEM_CREATION_ENDPOINT, payload=payload)

    def search_item(self, item_name: str) -> ApiResponse:
        payload = load_payload(
            "item_search_payload",
            values={"item_name": item_name},
            client_config=self.client_config,
        )
        return self.api_client.request("POST", ITEM_SEARCH_ENDPOINT, payload=payload)

    def create_item_relations(self, folder_uid: str, item_uid: str, relation_type: str) -> ApiResponse:
        payload = load_payload(
            "paste_created_object_under_folder_payload",
            values={
                "folder_uid": folder_uid,
                "item_uid": item_uid,
                "relation_type": relation_type,
            },
            client_config=self.client_config,
        )
        return self.api_client.request("POST", ITEM_CREATE_RELATIONS_ENDPOINT, payload=payload)

    def cut_item_from_folder(self, folder_uid: str, item_uid: str) -> ApiResponse:
        payload = load_payload(
            "cut_object_under_folder_payload",
            values={
                "folder_uid": folder_uid,
                "item_uid": item_uid,
            },
            client_config=self.client_config,
        )
        return self.api_client.request("POST", ITEM_REMOVE_CHILDREN_ENDPOINT, payload=payload)