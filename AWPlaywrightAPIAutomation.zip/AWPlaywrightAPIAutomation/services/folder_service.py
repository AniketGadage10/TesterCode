from __future__ import annotations

from core.base_service import BaseService
from models.api_response import ApiResponse
from utilities.payload_loader import load_payload

FOLDER_CREATION_ENDPOINT = "/tc/RestServices/Core-2016-09-DataManagement/createAttachAndSubmitObjects"
FOLDER_SEARCH_ENDPOINT = "/tc/RestServices/Internal-AWS2-2025-06-Finder/performSearchViewModel6"
FOLDER_DELETE_ENDPOINT = "/tc/RestServices/Core-2019-06-DataManagement/unlinkAndDeleteObjects"

class FolderService(BaseService):
    """Service for creating folders through the AWC data-management SOA endpoint."""

    service_name = "folder-service"

    def create_folder(self, folder_name: str, target_uid: str = "AAAAAAAAAAAAAA", target_type: str = "unknownType") -> ApiResponse:
        payload = load_payload(
            "folder_creation_payload",
            values={
                "folder_name": folder_name,
                "target_uid": target_uid,
                "target_type": target_type,
            },
            client_config=self.client_config,
        )
        return self.api_client.request("POST", FOLDER_CREATION_ENDPOINT, payload=payload)

    def search_folder(self, folder_name: str) -> ApiResponse:
            payload = load_payload(
                "folder_search_payload",
                values={"folder_name": folder_name},
                client_config=self.client_config,
            )

            return self.api_client.request("POST", FOLDER_SEARCH_ENDPOINT, payload=payload)

    def delete_folder(self, folder_uid: str) -> ApiResponse:
        payload = load_payload(
            "folder_delete_payload",
            values={"folder_uid": folder_uid},
            client_config=self.client_config,
        )
        return self.api_client.request("POST", FOLDER_DELETE_ENDPOINT, payload=payload)
    