from __future__ import annotations

from typing import Any

from core.base_service import BaseService
from core.exceptions import ResponseValidationError, UserSessionNotFoundError
from models.api_response import ApiResponse
from utilities.payload_loader import load_payload

SESSION_INFO_ENDPOINT = "/tc/JsonRestServices/Core-2007-01-Session/getTCSessionInfo"


class SessionInfoService(BaseService):
    """Service for fetching current AWC session information (user/group/role)."""

    service_name = "session-info-service"

    def get_session_info(self) -> ApiResponse:
        payload = load_payload("session_info_payload", client_config=self.client_config)
        response = self.api_client.request("POST", SESSION_INFO_ENDPOINT, payload=payload)
        return response

    def find_user_session(self, response_json: dict[str, Any]) -> str:
        service_data = response_json.get("ServiceData")
        if not isinstance(service_data, dict):
            raise ResponseValidationError("Missing ServiceData in session info response.")

        self._raise_if_partial_error(service_data)

        model_objects = service_data.get("modelObjects")
        updated = service_data.get("updated")

        if not isinstance(model_objects, dict):
            raise ResponseValidationError("ServiceData.modelObjects must be a dictionary.")
        if not isinstance(updated, list):
            raise ResponseValidationError("ServiceData.updated must be a list.")

        matches = [
            uid
            for uid, obj in model_objects.items()
            if isinstance(obj, dict)
            and obj.get("className") == "UserSession"
            and obj.get("type") == "UserSession"
            and uid in updated
        ]

        if len(matches) == 0:
            raise UserSessionNotFoundError("No UserSession object was found in the response.")
        if len(matches) > 1:
            raise UserSessionNotFoundError(
                f"Expected exactly one UserSession object, but found {len(matches)} matching entries."
            )

        return matches[0]

    def extract_session_properties(self, response_json: dict[str, Any], uid: str) -> tuple[str, str, str]:
        service_data = response_json.get("ServiceData")
        if not isinstance(service_data, dict):
            raise ResponseValidationError("Missing ServiceData in session info response.")

        model_objects = service_data.get("modelObjects")
        if not isinstance(model_objects, dict):
            raise ResponseValidationError("ServiceData.modelObjects must be a dictionary.")

        user_session = model_objects.get(uid)
        if not isinstance(user_session, dict):
            raise ResponseValidationError(f"UserSession object with UID {uid} is missing or malformed.")

        props = user_session.get("props")
        if not isinstance(props, dict):
            raise ResponseValidationError("UserSession.props must be a dictionary.")

        actual_user = self._extract_property(props, "user_id")
        actual_group = self._extract_property(props, "group_name")
        actual_role = self._extract_property(props, "role_name")

        return actual_user, actual_group, actual_role

    def _extract_property(self, props: dict[str, Any], property_name: str) -> str:
        property_value = props.get(property_name)
        if not isinstance(property_value, dict):
            raise ResponseValidationError(f"Missing or invalid property '{property_name}' in UserSession.")

        ui_values = property_value.get("uiValues")
        if not isinstance(ui_values, list) or len(ui_values) == 0:
            raise ResponseValidationError(f"Property '{property_name}.uiValues' must contain at least one value.")

        return str(ui_values[0])

    def _raise_if_partial_error(self, service_data: dict[str, Any]) -> None:
        for error_key in ("partialErrors", "PartialErrors", "partialError", "PartialError"):
            if service_data.get(error_key):
                raise ResponseValidationError(f"Session info response contains {error_key}.")
