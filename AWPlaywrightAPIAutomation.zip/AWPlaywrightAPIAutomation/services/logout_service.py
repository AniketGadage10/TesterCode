from __future__ import annotations

from core.auth_manager import AuthManager
from core.base_service import BaseService
from models.api_response import ApiResponse

LOGOUT_ENDPOINT = "/tc/RestServices/Core-2006-03-Session/logout"


class LogoutService(BaseService):
    """Service wrapping the Teamcenter AWC logout SOA endpoint."""

    service_name = "logout-service"

    def __init__(self, api_client, auth_manager: AuthManager, session_manager) -> None:  # noqa: ANN001
        super().__init__(api_client=api_client, session_manager=session_manager)
        self.auth_manager = auth_manager

    def logout(self) -> ApiResponse:
        payload = self.auth_manager.logout()
        response = self.api_client.request("POST", LOGOUT_ENDPOINT, payload=payload)
        self.session_manager.clear_session()
        return response
