from __future__ import annotations

from core.base_service import BaseService
from models.api_response import ApiResponse
from utilities.payload_loader import load_payload

CREATE_WORKFLOW_ENDPOINT = "/tc/RestServices/Workflow-2008-06-Workflow/createInstance"
APPROVE_WORKFLOW_ENDPOINT = "/tc/RestServices/Workflow-2014-06-Workflow/performAction3"

class WorkflowService(BaseService):
    """Service for workflow operations."""

    service_name = "workflow-service"

    def create_workflow(self, item_revision_uid: str, workflow_template: str, workflow_name: str) -> ApiResponse:
        """Create a workflow for the given item revision UID."""
        payload = load_payload(
            "create_workflow_payload",
            values={
                "item_revision_uid": item_revision_uid,
                "workflow_template": workflow_template,
                "workflow_name": workflow_name
            },
            client_config=self.client_config,
        )
        return self.api_client.request("POST", CREATE_WORKFLOW_ENDPOINT, payload=payload) 

    def approve_workflow_task(self, task_uid: str, comments: str = "Approved") -> ApiResponse:
        """Approve a workflow task by its ID."""
        payload = load_payload(
            "approve_workflow_payload",
            values={
                "task_uid": task_uid, 
                "comments": comments},
            client_config=self.client_config,
        )
        return self.api_client.request("POST", APPROVE_WORKFLOW_ENDPOINT, payload=payload) 

