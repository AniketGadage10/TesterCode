from __future__ import annotations

from core.auth_manager import AuthManager
from core.base_service import BaseService
from models.api_response import ApiResponse
from utilities.payload_loader import load_payload

LOGIN_ENDPOINT = "/tc/RestServices/Core-2011-06-Session/login"


class LoginService(BaseService):
    """Service wrapping the Teamcenter AWC login SOA endpoint."""

    service_name = "login-service"

    def __init__(self, api_client, auth_manager: AuthManager, session_manager) -> None:  # noqa: ANN001
        super().__init__(api_client=api_client, session_manager=session_manager)
        self.auth_manager = auth_manager

    def login(
        self,
        username: str | None = None,
        password: str | None = None,
        group: str | None = None,
        role: str | None = None,
        locale: str | None = None,
        descrimator: str | None = None,
    ) -> ApiResponse:
        self.session_manager.refresh_session()
        self.session_manager.bootstrap_session()

        users = self.session_manager.config.get("users", [])


        primary_user = users[0] if users and isinstance(users[0], dict) else {}

        resolved_username = username if username is not None else primary_user.get("username", "")
        resolved_password = password if password is not None else primary_user.get("password", "")
        resolved_group = group if group is not None else primary_user.get("group", "")
        resolved_role = role if role is not None else primary_user.get("role", "")
        resolved_locale = locale if locale is not None else primary_user.get("locale", "en_US")
       

        payload = load_payload(
            "login_payload",
            {
                "username": resolved_username,
                "password": resolved_password,
                "group": resolved_group,
                "role": resolved_role,
                "locale": resolved_locale
            },
            self.auth_manager._client_config,
        )
        
        try:
            response = self.api_client.request("POST", LOGIN_ENDPOINT, payload=payload)
        except Exception as exc:  # noqa: BLE001
            response = self._build_failure_response(str(exc))

        if self._is_login_success(response, resolved_username):
            self.session_manager.set_authenticated({"username": resolved_username})
        else:
            self.session_manager.clear_auth_state()
            if response.status in {401, 403} or response.is_success:
                self.session_manager.clear_session()
            if response.is_success:
                response = self._build_login_validation_failure(response, resolved_username)
            else:
                response = self._build_failure_response(
                    str(response.text()) or f"Login request failed with status {response.status}."
                )

        return response

    def _is_login_success(self, response: ApiResponse, username: str) -> bool:
        if response.status < 200 or response.status >= 300:
            return False

        if not response.is_success:
            return False

        payload = response.json()
        if not isinstance(payload, dict):
            return True

        explicit_error = self._extract_error_message(payload)
        if explicit_error:
            return False

        user_values = []
        for key in ("user", "username", "userName", "authenticatedUser", "authenticated_user"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                user_values.append(value.strip())

        if not user_values:
            return True

        expected_username = username.strip()
        return any(value.lower() == expected_username.lower() for value in user_values)

    def _extract_error_message(self, payload: dict[str, object]) -> str:
        for key in ("error", "errors", "message", "faultstring", "exception"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, dict):
                nested_error = self._extract_error_message(value)
                if nested_error:
                    return nested_error
        return ""

    def _build_failure_response(self, error_message: str) -> ApiResponse:
        class FailedResponse:
            status = 0

            def __init__(self, message: str) -> None:
                self._message = message

            def text(self) -> str:
                return self._message

            def json(self) -> dict[str, str]:
                return {"error": self._message}

        return ApiResponse(raw=FailedResponse(error_message), method="POST", url=LOGIN_ENDPOINT, elapsed_ms=0)

    def _build_login_validation_failure(self, response: ApiResponse, username: str) -> ApiResponse:
        payload = response.json()
        actual_user = ""
        if isinstance(payload, dict):
            for key in ("user", "username", "userName", "authenticatedUser", "authenticated_user"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    actual_user = value.strip()
                    break

        error_message = (
            f"Login failed: authenticated user '{actual_user or 'unknown'}' does not match requested username '{username}'."
        )

        class LoginValidationFailedResponse:
            status = 401

            def __init__(self, message: str, original_response: ApiResponse) -> None:
                self._message = message
                self._original_response = original_response

            def text(self) -> str:
                return self._message

            def json(self) -> dict[str, str]:
                return {"error": self._message}

        return ApiResponse(
            raw=LoginValidationFailedResponse(error_message, response),
            method=response.method,
            url=response.url,
            elapsed_ms=response.elapsed_ms,
        )
