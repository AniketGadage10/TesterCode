from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any

import yaml

CONFIG_DIR = Path(__file__).resolve().parent
VALID_ENVS = ("dev", "qa", "prod")


class ConfigurationError(Exception):
    """Raised when configuration is missing, invalid, or cannot be resolved."""


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ConfigurationError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge `override` on top of `base` without mutating either."""
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _apply_env_overrides(config: dict[str, Any]) -> dict[str, Any]:
    """Apply environment-variable overrides for secrets and other values that
    should never live in a committed YAML file.

    Supported overrides:
        AWC_BASE_URL   -> config["base_url"]
        AWC_USERNAME   -> config["users"][0]["username"]
        AWC_PASSWORD   -> config["users"][0]["password"]
        AWC_GROUP      -> config["users"][0]["group"]
        AWC_ROLE       -> config["users"][0]["role"]
        AWC_LOCALE     -> config["users"][0]["locale"]
        AWC_LOG_LEVEL  -> config["logging"]["level"]
    """
    if os.getenv("AWC_BASE_URL"):
        config["base_url"] = os.environ["AWC_BASE_URL"]

    users = config.get("users") or [{}]
    primary_user = dict(users[0]) if users else {}

    env_field_map = {
        "AWC_USERNAME": "username",
        "AWC_PASSWORD": "password",
        "AWC_GROUP": "group",
        "AWC_ROLE": "role",
        "AWC_LOCALE": "locale",
    }
    for env_var, field in env_field_map.items():
        value = os.getenv(env_var)
        if value is not None:
            primary_user[field] = value

    config["users"] = [primary_user, *users[1:]] if users else [primary_user]

    if os.getenv("AWC_LOG_LEVEL"):
        config.setdefault("logging", {})["level"] = os.environ["AWC_LOG_LEVEL"]

    return config


def _validate(config: dict[str, Any], env: str) -> None:
    if not config.get("base_url"):
        raise ConfigurationError(f"'base_url' is not set for environment '{env}'.")
    users = config.get("users")
    if not users or not isinstance(users, list):
        raise ConfigurationError(f"No 'users' configured for environment '{env}'.")


def get_config(env: str | None = None) -> dict[str, Any]:
    """Load configuration for the given environment.

    Resolution order (lowest to highest precedence):
        1. config/base.yaml            (shared defaults)
        2. config/<env>.yaml           (environment overrides)
        3. AWC_* environment variables (secrets / CI overrides)
    """
    env = (env or os.getenv("ENV", "dev")).strip().lower()
    if env not in VALID_ENVS:
        raise ConfigurationError(f"Unknown environment '{env}'. Expected one of {VALID_ENVS}.")

    base_config = _load_yaml(CONFIG_DIR / "base.yaml")
    env_config = _load_yaml(CONFIG_DIR / f"{env}.yaml")
    merged = _deep_merge(base_config, env_config)
    merged = _apply_env_overrides(merged)
    merged["env"] = env

    _validate(merged, env)
    return merged
