# Jenkins Setup Guide for Playwright API Automation

This document provides instructions for setting up and running this project in Jenkins.

## Prerequisites

### Jenkins Setup
- Jenkins 2.414+ with Pipeline support
- Python 3.11+ installed on Jenkins agents
- Git plugin configured

### Required Jenkins Plugins
- Pipeline (Declarative Pipeline)
- HTML Publisher Plugin (for test reports)
- Timestamper Plugin (recommended)

### Install Plugins
1. Go to **Manage Jenkins** → **Manage Plugins**
2. Search for and install:
   - `Pipeline`
   - `HTML Publisher`
   - `Timestamper`

## Configuration Steps

### 1. Create a New Pipeline Job
1. Click **New Item** in Jenkins
2. Enter job name: `AWPlaywrightAPIAutomation`
3. Select **Pipeline**
4. Click **OK**

### 2. Configure Pipeline
1. Under **Pipeline** section, set:
   - **Definition**: `Pipeline script from SCM`
   - **SCM**: `Git`
   - **Repository URL**: `<your-git-repo-url>`
   - **Branch Specifier**: `*/main` (or your default branch)
   - **Script Path**: `Jenkinsfile`

### 3. Setup Build Parameters (Optional)
The Jenkinsfile includes build parameters:
- **TEST_MARKER**: Choose which tests to run (api, smoke, regression, critical)
- **ENVIRONMENT**: Target environment (dev, qa, prod)

### 4. Configure Environment Variables (Optional)
Add credentials for sensitive data:
1. Go to **Manage Jenkins** → **Manage Credentials**
2. Create credentials for:
   - `AWC_USERNAME` - API username
   - `AWC_PASSWORD` - API password
   - Store as **Secret text** credentials

Then reference in Jenkins job:
```groovy
environment {
    AWC_USERNAME = credentials('awc-username')
    AWC_PASSWORD = credentials('awc-password')
}
```

### 5. Configure .env File
The Jenkinsfile uses the `.env` file from the repository. Make sure:
- `.env` is not committed to Git (add to `.gitignore`)
- For Jenkins, create a `.env` file on the Jenkins workspace or use Jenkins credentials plugin

Alternative: Pass environment variables through Jenkins:
```groovy
environment {
    AWC_BASE_URL = credentials('awc-base-url')
    AWC_USERNAME = credentials('awc-username')
    AWC_PASSWORD = credentials('awc-password')
}
```

## Running Tests

### Manual Trigger
1. Open the job in Jenkins
2. Click **Build with Parameters**
3. Select test marker and environment
4. Click **Build**

### Scheduled Runs
To run tests on a schedule (e.g., nightly):
1. Go to **Configure** → **Build Triggers**
2. Check **Build periodically**
3. Enter cron expression:
   - Nightly: `H 2 * * *` (at 2 AM)
   - Every 2 hours: `H */2 * * *`
   - Every day at 9 AM: `0 9 * * *`

### Webhook Integration
To trigger on Git pushes:
1. In **Configure** → **Build Triggers**, check **GitHub hook trigger for GITScm polling**
2. Configure webhook in your Git repository pointing to Jenkins

## Test Reports

### Pytest HTML Report
- Generated at: `reports/pytest-report.html`
- Accessible in Jenkins UI under **Pytest HTML Report**
- Contains detailed test results and execution details

### Logs
- Application logs: `logs/`
- Jenkins console output: Available in Jenkins UI

## Troubleshooting

### Python Not Found
```
'python' is not recognized as an internal or external command
```
**Solution**: Ensure Python 3.11+ is installed and in PATH on Jenkins agent.

### Virtual Environment Issues
```
The system cannot find the path specified.
```
**Solution**: Check that `.venv` directory has write permissions in Jenkins workspace.

### Playwright Issues
```
Error: Playwright browsers not installed
```
**Solution**: The Jenkinsfile includes `playwright install` step. Ensure it runs successfully.

### Test Report Not Generated
```
Reports directory is empty
```
**Solution**: Ensure pytest completes successfully. Check console output for test errors.

### Test Failures in Jenkins but Not Locally
**Common causes**:
- Different environment configuration (check `ENVIRONMENT` parameter)
- Network connectivity to target server
- Missing credentials in Jenkins

**Debug**:
1. Check console output for detailed error messages
2. Review logs in `logs/` directory
3. Verify credentials are correctly configured

## Maintenance

### Cleanup Logs and Reports
The Jenkinsfile automatically keeps the last 10 builds. Older artifacts are automatically deleted.

### Update Dependencies
To update dependencies:
1. Update `requirements.txt` or `requirements-dev.txt` locally
2. Commit and push changes
3. Run pipeline - it will reinstall dependencies

## Example Cron Schedules

| Schedule | Cron Expression |
|----------|---|
| Every day at 9 AM | `0 9 * * *` |
| Every weekday at 8 AM | `0 8 * * 1-5` |
| Every 4 hours | `H */4 * * *` |
| Every Sunday at 2 AM | `H 2 * * 0` |

## Integrations

### Slack Notifications
Add to Jenkinsfile post-stage:
```groovy
post {
    failure {
        slackSend(color: 'danger', message: "Tests failed: ${env.BUILD_URL}")
    }
    success {
        slackSend(color: 'good', message: "Tests passed: ${env.BUILD_URL}")
    }
}
```

### Email Notifications
In **Configure** → **Post-build Actions**, add **Email Notification**.

## References

- [Jenkins Pipeline Documentation](https://www.jenkins.io/doc/book/pipeline/)
- [Pytest Documentation](https://docs.pytest.org/)
- [Playwright Documentation](https://playwright.dev/python/)
