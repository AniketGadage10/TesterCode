# AWPlaywrightAPIAutomation

A lightweight Playwright + Python API automation framework for Teamcenter Active Workspace (AWC).

## Project structure

```text
config/      Environment configuration files
core/        Shared automation core: session handling, HTTP client, retries, cookies
models/      Request/response wrapper models
services/    Login, logout, and session-info services
testdata/    JSON payload templates
tests/       Pytest test cases
utilities/   Logging, YAML/JSON helpers, payload loading helpers
```

## Prerequisites

- Python 3.10 or newer
- Windows PowerShell 5.1 or newer
- Internet access for downloading packages and Playwright browsers

## 1. Create and activate the virtual environment

Open PowerShell in the project root and run:

```powershell
cd C:\path\to\AWPlaywrightAPIAutomation
py -3 -m venv .venv
```

If PowerShell blocks script execution, run this once for the current terminal session:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate the virtual environment:

```powershell
.\.venv\Scripts\Activate.ps1
```

If you want to allow script execution for your user account permanently, use:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

## 2. Install dependencies

With the virtual environment active:

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
```

Install the Playwright browser binaries:

```powershell
python -m playwright install
```

## 3. Configure environment variables

Create a `.env` file in the project root with your test environment values:

```text
AWC_USERNAME=your_username
AWC_PASSWORD=your_password
AWC_BASE_URL=https://your-teamcenter-host
AWC_GROUP=Engineering
AWC_ROLE=Analyst
AWC_LOCALE=en_US
```

## 4. Run tests

Run the full suite:

```powershell
python -m pytest -q
```

Run one test file:

```powershell
python -m pytest -q tests/test_validate_logged_in_user_group_role.py
```

Run with verbose output:

```powershell
python -m pytest tests/test_validate_logged_in_user_group_role.py -v
```

## 5. View test results

Open the HTML report:

```powershell
start .\reports\pytest-report.html
```

## 6. Optional quality checks

```powershell
python -m ruff check .
python -m mypy .
```

## 7. Leave the virtual environment

```powershell
deactivate
```

## Troubleshooting

- If you see `running scripts is disabled on this system`, run:

  ```powershell
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  ```

- If you get `ModuleNotFoundError`, make sure the virtual environment is active and dependencies were installed successfully.
- If Playwright fails, reinstall browsers with:

  ```powershell
  python -m playwright install
  ```

## Notes

- Payloads are loaded from JSON files in the testdata folder.
- The test framework uses shared session state for cookies, CSRF tokens, and request context.