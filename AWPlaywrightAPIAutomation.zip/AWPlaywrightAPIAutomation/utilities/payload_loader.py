from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


def load_payload(
    template_name: str,
    values: dict[str, Any] | None = None,
    client_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Load a payload template from the testdata folder and inject runtime values."""
    payload_path = Path(__file__).resolve().parent.parent / "testdata" / f"{template_name}.json"
    if not payload_path.exists():
        raise FileNotFoundError(f"Payload template not found: {payload_path}")

    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    payload = _resolve_placeholders(payload, values or {})
    payload = _apply_runtime_values(payload, values or {})

    client_config = client_config or {}
    header_state = payload.setdefault("header", {}).setdefault("state", {})
    if isinstance(header_state, dict):
        header_state.update(client_config)

    return payload


def _resolve_placeholders(value: Any, values: dict[str, Any]) -> Any:
    defaults = {
        "username": "",
        "password": "",
        "group": "",
        "role": "",
        "locale": "en_US",
        "descrimator": "AWC2897",
    }
    resolved_values = {**defaults, **values}

    if isinstance(value, str):
        resolved = value
        for key, replacement in resolved_values.items():
            resolved = resolved.replace(f"{{{{{key}}}}}", str(replacement))
            resolved = resolved.replace(f"__{key.upper()}__", str(replacement))
        return resolved

    if isinstance(value, dict):
        return {key: _resolve_placeholders(item, resolved_values) for key, item in value.items()}

    if isinstance(value, list):
        return [_resolve_placeholders(item, resolved_values) for item in value]

    return deepcopy(value)


def _apply_runtime_values(value: Any, values: dict[str, Any]) -> Any:
    if isinstance(value, dict):
        updated = {}
        for key, item in value.items():
            if key == "user" and values.get("username") is not None:
                updated[key] = values["username"]
            elif key == "password" and values.get("password") is not None:
                updated[key] = values["password"]
            elif key == "group" and values.get("group") is not None:
                updated[key] = values["group"]
            elif key == "role" and values.get("role") is not None:
                updated[key] = values["role"]
            elif key == "locale" and values.get("locale") is not None:
                updated[key] = values["locale"]
            elif key == "descrimator" and values.get("descrimator") is not None:
                updated[key] = values["descrimator"]
            else:
                updated[key] = _apply_runtime_values(item, values)
        return updated

    if isinstance(value, list):
        return [_apply_runtime_values(item, values) for item in value]

    return deepcopy(value)
