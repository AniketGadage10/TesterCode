from __future__ import annotations

import logging
from contextvars import ContextVar
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

_correlation_id: ContextVar[str] = ContextVar("correlation_id", default="-")

#_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"
_FORMAT = "%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"

class _CorrelationIdFilter(logging.Filter):
    """Injects the current test's correlation id into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.correlation_id = _correlation_id.get()
        return True


def set_correlation_id(value: str) -> None:
    """Set the correlation id (e.g. current test node id) for this context.
    All subsequent log records emitted via `get_logger` loggers will include it.
    """
    _correlation_id.set(value)


def get_logger(
    name: str = "framework",
    level: str = "INFO",
    log_file: Optional[str] = None,
    *,
    max_bytes: int = 5_242_880,
    backup_count: int = 5,
) -> logging.Logger:
    """Get (or create) a logger writing to both a rotating file and stdout.

    Safe to call repeatedly with the same `name`/`log_file`: handlers are
    only attached once per logger instance.
    """
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    if log_file:
        log_path = Path(log_file)
        if not log_path.is_absolute() and log_path.parent == Path("."):
            log_path = log_dir / log_path.name
    else:
        log_path = log_dir / "framework.log"

    log_path.parent.mkdir(parents=True, exist_ok=True)
    if log_path.exists():
        log_path.write_text("", encoding="utf-8")

    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.propagate = False

    if logger.handlers:
        return logger

    formatter = logging.Formatter(_FORMAT)
    correlation_filter = _CorrelationIdFilter()

    file_handler = RotatingFileHandler(log_path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8")
    file_handler.setFormatter(formatter)
    file_handler.addFilter(correlation_filter)
    logger.addHandler(file_handler)

    return logger


# Backwards-compatible alias used throughout the framework.
getlogger = get_logger


class ListHandler(logging.Handler):
    """Logging handler that appends formatted records to an in-memory list,
    useful for asserting on log output within a single test.
    """

    def __init__(self, records_list: list[str]) -> None:
        super().__init__()
        self.records = records_list

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
        except Exception:  # noqa: BLE001 - logging must never raise
            msg = record.getMessage()
        self.records.append(msg)


def create_logger(
    name: str = "framework",
    level: str = "INFO",
    log_file: Optional[str] = None,
    capture_list: Optional[list[str]] = None,
) -> tuple[logging.Logger, Optional[list[str]]]:
    """Create a logger like `get_logger`, optionally attaching an in-memory
    list handler so a test can assert on emitted log lines.

    Returns a tuple `(logger, records)` where `records` is the list provided
    (or None if `capture_list` was not given).
    """
    logger = get_logger(name=name, level=level, log_file=log_file)
    if capture_list is not None:
        handler = ListHandler(capture_list)
        handler.setFormatter(logging.Formatter(_FORMAT))
        handler.addFilter(_CorrelationIdFilter())
        logger.addHandler(handler)
    return logger, capture_list


def log_step(logger: logging.Logger, message: str, *, level: str = "info") -> None:
    """Log a test step message with a clear `STEP` prefix."""
    text = f"STEP: {message}"
    getattr(logger, level.lower(), logger.info)(text)


class Step:
    """Context manager marking the start/end of a test step."""

    def __init__(self, logger: logging.Logger, message: str, *, level: str = "info") -> None:
        self.logger = logger
        self.message = message
        self.level = level

    def __enter__(self) -> "Step":
        log_step(self.logger, f"START: {self.message}", level=self.level)
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> bool:
        suffix = "- FAILED" if exc_type is not None else "- DONE"
        log_step(self.logger, f"END: {self.message} {suffix}", level=self.level)
        return False  # never suppress exceptions


def debug(logger: logging.Logger, message: str) -> None:
    """Convenience wrapper for `logger.debug`."""
    logger.debug(message)
