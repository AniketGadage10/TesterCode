from __future__ import annotations

import random


def generate_random_number(length: int = 4) -> int:
    """Generate a random integer with the requested number of digits."""
    if length <= 0:
        raise ValueError("length must be greater than zero")

    min_value = 10 ** (length - 1)
    max_value = (10 ** length) - 1
    return random.randint(min_value, max_value)
