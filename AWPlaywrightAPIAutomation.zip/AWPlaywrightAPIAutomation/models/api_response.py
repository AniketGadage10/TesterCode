from __future__ import annotations

from typing import Any


class ApiResponse:
    """Simple wrapper that mirrors the Playwright response surface used by services."""

    def __init__(self, raw: Any, method: str, url: str, elapsed_ms: float) -> None:
        self._raw = raw
        self.method = method
        self.url = url
        self.elapsed_ms = elapsed_ms

    @property
    def status(self) -> int:
        return getattr(self._raw, "status", 0)

    @property
    def headers(self) -> dict[str, Any]:
        return getattr(self._raw, "headers", {}) or {}

    def text(self) -> str:
        return getattr(self._raw, "text", lambda: "")()

    def json(self) -> Any:
        return getattr(self._raw, "json", lambda: None)()

    @property
    def is_success(self) -> bool:
        if not 200 <= self.status < 300:
            return False

        try:
            payload = self.json()
        except Exception:  # noqa: BLE001
            payload = None

        if self._contains_failure_indicator(payload):
            return False

        response_text = (self.text() or "").strip()
        if not response_text:
            return True

        lowered = response_text.lower()
        failure_tokens = (
            "login failed",
            "invalid credentials",
            "invalid username",
            "invalid password",
            "authentication failed",
            "unauthorized",
            "forbidden",
            "access denied",
            "permission denied",
        )
        return not any(token in lowered for token in failure_tokens)

    def _contains_failure_indicator(self, payload: Any) -> bool:
        if payload is None or payload is False:
            return False

        if isinstance(payload, dict):
            for key, value in payload.items():
                normalized_key = str(key).lower()
                if normalized_key in {"error", "errors", "partialerrors", "partialerror", "fault", "faultstring", "exception"}:
                    return self._is_failure_value(value)
                if normalized_key in {"status", "result"} and isinstance(value, str):
                    lowered_value = value.lower()
                    if lowered_value in {"error", "failed", "failure", "invalid", "unauthorized", "forbidden", "access denied"}:
                        return True
                if normalized_key == "message" and isinstance(value, str):
                    lowered_message = value.lower()
                    if any(token in lowered_message for token in ("failed", "invalid", "unauthorized", "forbidden", "access denied", "permission denied")):
                        return True
                if self._contains_failure_indicator(value):
                    return True
        elif isinstance(payload, list):
            return any(self._contains_failure_indicator(item) for item in payload)
        return False

    def _is_failure_value(self, value: Any) -> bool:
        if value is None or value is False:
            return False
        if value is True:
            return True
        if isinstance(value, str):
            lowered_value = value.lower().strip()
            return bool(lowered_value) and any(token in lowered_value for token in ("failed", "invalid", "unauthorized", "forbidden", "access denied", "permission denied"))
        if isinstance(value, dict):
            return any(self._is_failure_value(item) for item in value.values())
        if isinstance(value, list):
            return any(self._is_failure_value(item) for item in value)
        return bool(value)
