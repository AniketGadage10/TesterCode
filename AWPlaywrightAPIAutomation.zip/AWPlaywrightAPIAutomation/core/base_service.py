from __future__ import annotations

from typing import Any

from core.api_client import APIClient
from core.session_manager import SessionManager


class BaseService:
    """Common scaffolding for business-facing services: a shared API client,
    session manager, and a named logger. Subclasses focus purely on building
    request payloads and interpreting responses for their endpoint(s).
    """

    #: Override in subclasses, used as both the logger name and for logging context.
    service_name: str = "service"

    def __init__(self, api_client: APIClient, session_manager: SessionManager) -> None:
        self.api_client = api_client
        self.session_manager = session_manager

    @property
    def client_config(self) -> dict[str, Any]:
        return self.session_manager.config.get("client", {})
