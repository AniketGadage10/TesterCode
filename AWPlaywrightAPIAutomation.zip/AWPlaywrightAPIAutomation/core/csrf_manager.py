from __future__ import annotations

import re
from typing import Any


class CSRFManager:
    """Captures and stores CSRF tokens from headers, cookies, and response bodies."""

    def __init__(self) -> None:
        self._tokens: dict[str, str] = {}

    def update_from_response(self, response_headers: dict[str, str] | None = None, response_body: Any = None, cookies: list[dict[str, Any]] | None = None) -> None:
        if response_headers:
            for key, value in response_headers.items():
                if key.lower() in {"x-csrf-token", "x-xsrf-token", "xsrf-token", "csrf-token"}:
                    self._tokens[key.lower()] = value
        if cookies:
            for cookie in cookies:
                name = cookie.get("name", "")
                if name.lower() in {"x-csrf-token", "x-xsrf-token", "xsrf-token", "xsrftoken", "csrf-token", "_csrf"}:
                    self._tokens[name.lower()] = cookie.get("value", "")
                if name.lower() in {"xsrf-token", "xsrftoken"}:
                    self._tokens["x-xsrf-token"] = cookie.get("value", "")
        if response_body:
            if isinstance(response_body, str):
                body_text = response_body
            else:
                body_text = str(response_body)
            for token_name in ("x-csrf-token", "x-xsrf-token", "xsrf-token", "csrf-token"):
                match = re.search(rf'{token_name}[^\w]?[:=]\s*([A-Za-z0-9_\-]+)', body_text, re.IGNORECASE)
                if match:
                    self._tokens[token_name] = match.group(1)

    def get_tokens(self) -> dict[str, str]:
        return dict(self._tokens)

    def get_headers(self) -> dict[str, str]:
        headers = {}
        for key, value in self._tokens.items():
            if key.lower() in {"x-csrf-token", "x-xsrf-token", "xsrf-token", "xsrftoken", "csrf-token", "_csrf"}:
                normalized_key = "X-CSRF-Token" if key.lower() in {"x-csrf-token", "csrf-token"} else "X-XSRF-TOKEN"
                headers[normalized_key] = value
        if "X-CSRF-Token" not in headers and "X-XSRF-TOKEN" in headers:
            headers["X-CSRF-Token"] = headers["X-XSRF-TOKEN"]
        if "X-XSRF-TOKEN" not in headers and "X-CSRF-Token" in headers:
            headers["X-XSRF-TOKEN"] = headers["X-CSRF-Token"]
        return headers

    def clear(self) -> None:
        self._tokens.clear()
