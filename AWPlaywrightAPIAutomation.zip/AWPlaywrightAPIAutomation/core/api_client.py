from __future__ import annotations

import json
import time
from typing import Any

from core.exceptions import RetryableStatusError
from core.request_interceptor import RequestInterceptor
from core.session_manager import SessionManager
from models.api_response import ApiResponse


class APIClient:
    """Reusable HTTP client wrapper around the Playwright API request context.

    Centralizes header/cookie/CSRF injection, retry-on-transient-status
    behaviour, timing, and (redacted) request/response logging so services
    never talk to Playwright directly.
    """

    def __init__(self, session_manager: SessionManager) -> None:
        self.session_manager = session_manager
        self.interceptor = RequestInterceptor(session_manager)
        self.retry_on_status: set[int] = set(
            session_manager.config.get("api", {}).get("retry_on_status", [403, 429, 500, 502, 503, 504])
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: int | None = None,
    ) -> ApiResponse:
        url = self._build_url(path)

        def send_request() -> ApiResponse:
            request_context = self.session_manager.get_request_context()
            final_headers = self.interceptor.build_headers(headers)

            request_method = getattr(request_context, method.lower(), None)
            if request_method is None:
                raise ValueError(f"Unsupported HTTP method: {method}")

            timeout_seconds = timeout or self.session_manager.config.get("api", {}).get("timeout", 30)
            started_at = time.perf_counter()
            request_body = self._prepare_request_body(payload, final_headers)
            raw_response = request_method(
                url,
                headers=final_headers,
                data=request_body,
                timeout=timeout_seconds * 1000,
            )
    
            elapsed_ms = (time.perf_counter() - started_at) * 1000
            response = ApiResponse(raw=raw_response, method=method.upper(), url=url, elapsed_ms=elapsed_ms)
            self._sync_session_state(response)

            if response.status in self.retry_on_status:
                # Surface the server response body in the exception message so
                # callers (and tests) can see why the server returned a
                # retryable status like 500 rather than getting a silent
                # RetryableStatusError with no context.
                raise RetryableStatusError(response.status, message=response.text())
            return response

        try:
            response = self.session_manager.retry_handler.run(
                send_request,
                should_retry=lambda exc: isinstance(exc, RetryableStatusError),
            )
        except RetryableStatusError:
         
            raise

        self._sync_session_state(response)
        return response

    def _prepare_request_body(self, payload: dict[str, Any] | None, headers: dict[str, str]) -> Any:
        if payload is None:
            return None
        if isinstance(payload, (str, bytes, bytearray)):
            return payload
        content_type = headers.get("Content-Type", "") or headers.get("content-type", "")
        if isinstance(payload, (dict, list)) and content_type.lower().startswith("application/json"):
            return json.dumps(payload)
        return payload

    def _sync_session_state(self, response: ApiResponse) -> None:
        raw_cookies = response.headers.get("set-cookie", [])
        parsed_cookies = self.session_manager.parse_set_cookie_values(raw_cookies)
        if parsed_cookies:
            self.session_manager.add_cookies(parsed_cookies)
        self.session_manager.set_csrf_tokens(
            response_headers=response.headers,
            response_body=response.text(),
            cookies=parsed_cookies,
        )

    def _build_url(self, path: str) -> str:
        base_url = self.session_manager.base_url.rstrip("/")
        path = path.lstrip("/")
        return f"{base_url}/{path}"
