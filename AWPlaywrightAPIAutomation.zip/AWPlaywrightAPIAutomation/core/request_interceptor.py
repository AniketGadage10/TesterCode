from __future__ import annotations

from typing import Any


class RequestInterceptor:
    """Applies common headers (Accept, Content-Type, CSRF, cookies) to every
    outgoing request so services never build these headers by hand.
    """

    def __init__(self, session_manager: Any) -> None:
        self.session_manager = session_manager

    def build_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        headers.update(self.session_manager.get_common_headers())
        headers.update(self.session_manager.get_cookie_header())
        if extra_headers:
            headers.update(extra_headers)

        # Teamcenter accepts either CSRF header name; mirror whichever one we have.
        if "X-CSRF-Token" not in headers and "X-XSRF-TOKEN" in headers:
            headers["X-CSRF-Token"] = headers["X-XSRF-TOKEN"]
        if "X-XSRF-TOKEN" not in headers and "X-CSRF-Token" in headers:
            headers["X-XSRF-TOKEN"] = headers["X-CSRF-Token"]
        return headers

