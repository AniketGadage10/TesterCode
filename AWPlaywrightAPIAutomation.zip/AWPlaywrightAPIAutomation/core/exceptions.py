from __future__ import annotations


class FrameworkError(Exception):
    """Base class for all custom framework exceptions."""


class ConfigurationError(FrameworkError):
    """Raised when configuration is missing, invalid, or cannot be resolved."""


class ResponseValidationError(FrameworkError):
    """Raised when an API response is malformed or missing expected data."""


class UserSessionNotFoundError(FrameworkError):
    """Raised when the UserSession object cannot be uniquely resolved."""


class APIRequestForbiddenError(FrameworkError):
    """Raised when an API request returns HTTP 403 and should be retried."""


class RetryableStatusError(FrameworkError):
    """Raised when an API request returns a status code configured as retryable."""

    def __init__(self, status: int, message: str | None = None) -> None:
        self.status = status
        super().__init__(message or f"Received retryable HTTP status {status}.")
