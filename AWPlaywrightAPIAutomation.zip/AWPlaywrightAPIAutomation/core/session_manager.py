from __future__ import annotations

from http.cookies import SimpleCookie
from typing import Any

from playwright.sync_api import APIRequestContext

from core.cookie_manager import CookieManager
from core.csrf_manager import CSRFManager
from core.playwright_context import PlaywrightContext
from core.retry_handler import RetryHandler


class SessionManager:
    """Singleton that manages the Playwright request context, cookies, CSRF
    tokens, and authentication state for a single test session.

    Use `SessionManager.get_instance(...)` rather than the constructor
    directly so the same context/cookies are shared across services within
    a test. Call `reset()` (typically from a fixture) to force a fresh
    instance between tests.
    """

    _instance: "SessionManager | None" = None

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.base_url = config.get("base_url", "")
        self.context = PlaywrightContext.get_instance(self.base_url)
        self.request_context: APIRequestContext | None = None
        self.cookie_manager = CookieManager()
        self.csrf_manager = CSRFManager()

        api_config = config.get("api", {})
        self.retry_handler = RetryHandler(
            retries=api_config.get("retries", 3),
            delay=api_config.get("retry_delay", 1.0),
            backoff_factor=api_config.get("retry_backoff_factor", 2.0),
        )
        self.auth_state: dict[str, Any] = {}
        self._session_active = False

    @classmethod
    def get_instance(cls, config: dict[str, Any]) -> "SessionManager":
        if cls._instance is None:
            cls._instance = cls(config=config)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Drop the cached singleton instance. Intended for use in fixtures
        so each test starts from a clean session.
        """
        cls._instance = None

    # -- lifecycle ---------------------------------------------------------

    def create_session(self) -> APIRequestContext:
        self.request_context = self.context.create_context()
        return self.request_context

    def get_request_context(self) -> APIRequestContext:
        if self.request_context is None:
            return self.create_session()
        return self.request_context

    def close(self) -> None:
        self.context.close()
        self.request_context = None
        type(self)._instance = None

    def refresh_session(self) -> None:
        self.clear_session()
        self.context.close()
        self.request_context = None
        self.create_session()

    def __enter__(self) -> "SessionManager":
        self.create_session()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    # -- cookies -------------------------------------------------------------

    def set_cookies(self, cookies: list[dict[str, Any]]) -> None:
        self.cookie_manager.set_cookies(cookies)

    def add_cookies(self, cookies: list[dict[str, Any]]) -> None:
        existing = {cookie["name"]: cookie for cookie in self.cookie_manager.get_cookies()}
        for cookie in cookies:
            name = cookie.get("name")
            value = cookie.get("value")
            if name and value:
                existing[name] = {"name": name, "value": value}
        self.cookie_manager.set_cookies(list(existing.values()))

    def get_cookies(self) -> list[dict[str, Any]]:
        return self.cookie_manager.get_cookies()

    def get_cookie_header(self) -> dict[str, str]:
        cookies = self.get_cookies()
        if not cookies:
            return {}
        cookie_value = "; ".join(
            f"{cookie['name']}={cookie['value']}" for cookie in cookies if cookie.get("name") and cookie.get("value")
        )
        return {"Cookie": cookie_value} if cookie_value else {}

    @staticmethod
    def parse_set_cookie_values(raw_cookies: str | list[str] | None) -> list[dict[str, Any]]:
        cookie_list = raw_cookies if isinstance(raw_cookies, list) else [raw_cookies] if raw_cookies else []
        parsed_cookies: list[dict[str, Any]] = []
        for item in cookie_list:
            cookie: SimpleCookie = SimpleCookie()
            cookie.load(item)
            for morsel in cookie.values():
                parsed_cookies.append({"name": morsel.key, "value": morsel.value})
        return parsed_cookies

    # -- CSRF ------------------------------------------------------------

    def set_csrf_tokens(
        self,
        response_headers: dict[str, str] | None = None,
        response_body: Any = None,
        cookies: list[dict[str, Any]] | None = None,
    ) -> None:
        self.csrf_manager.update_from_response(response_headers=response_headers, response_body=response_body, cookies=cookies)

    def get_common_headers(self) -> dict[str, str]:
        return self.csrf_manager.get_headers()

    # -- auth state -----------------------------------------------------

    def set_authenticated(self, state: dict[str, Any]) -> None:
        self.auth_state = state
        self._session_active = True

    def is_authenticated(self) -> bool:
        return self._session_active and bool(self.auth_state)

    def clear_auth_state(self) -> None:
        self.auth_state = {}
        self._session_active = False

    def clear_session(self) -> None:
        self.clear_auth_state()
        self.cookie_manager.clear()
        self.csrf_manager.clear()

    # -- bootstrap --------------------------------------------------------

    def bootstrap_session(self) -> Any:
        """Issue an initial GET to the base URL to seed cookies/CSRF tokens
        before the first authenticated request.
        """
        request_context = self.get_request_context()
        try:
            response = request_context.get(self.base_url.rstrip("/") + "/")
        except Exception:  # noqa: BLE001
            return None

        raw_cookies = response.headers.get("set-cookie", [])
        parsed_cookies = self.parse_set_cookie_values(raw_cookies)
        self.set_csrf_tokens(
            response_headers=dict(response.headers),
            response_body=response.text(),
            cookies=parsed_cookies,
        )
        self.cookie_manager.set_cookies(parsed_cookies)
        return response
