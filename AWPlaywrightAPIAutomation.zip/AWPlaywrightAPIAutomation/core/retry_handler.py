from __future__ import annotations

import random
import time
from typing import Callable, TypeVar

T = TypeVar("T")


class RetryHandler:
    """Retry wrapper with exponential backoff and optional jitter for transient
    API errors (e.g. 403 CSRF hiccups, 429 rate limiting, 5xx server errors).
    """

    def __init__(
        self,
        retries: int = 3,
        delay: float = 1.0,
        backoff_factor: float = 2.0,
        jitter: float = 0.1,
    ) -> None:
        self.retries = max(0, retries)
        self.delay = max(0.0, delay)
        self.backoff_factor = max(1.0, backoff_factor)
        self.jitter = max(0.0, jitter)

    def _sleep_duration(self, attempt: int) -> float:
        base = self.delay * (self.backoff_factor**attempt)
        jitter_amount = base * self.jitter
        return base + random.uniform(-jitter_amount, jitter_amount) if jitter_amount else base

    def run(self, func: Callable[[], T], *, should_retry: Callable[[Exception], bool] | None = None) -> T:
        """Execute `func`, retrying with exponential backoff when `should_retry`
        returns True for the raised exception. Re-raises the last exception once
        retries are exhausted, or immediately if `should_retry` returns False.
        """
        last_exception: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                return func()
            except Exception as exc:  # noqa: BLE001 - intentionally broad, re-raised below
                last_exception = exc
                if should_retry is not None and not should_retry(exc):
                    raise
                if attempt >= self.retries:
                    raise
                sleep_for = self._sleep_duration(attempt)
                time.sleep(sleep_for)
        if last_exception is not None:
            raise last_exception
        raise RuntimeError("Retry handler failed without capturing an exception.")
