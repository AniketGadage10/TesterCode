from __future__ import annotations

from typing import Any


class CookieManager:
    """Central store for cookies captured from the request context."""

    def __init__(self) -> None:
        self._cookies: list[dict[str, Any]] = []

    def set_cookies(self, cookies: list[dict[str, Any]]) -> None:
        self._cookies = cookies

    def get_cookies(self) -> list[dict[str, Any]]:
        return list(self._cookies)

    def clear(self) -> None:
        self._cookies.clear()
