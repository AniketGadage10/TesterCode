from __future__ import annotations

from typing import Any

from core.session_manager import SessionManager
from utilities.payload_loader import load_payload


class AuthManager:
    """High-level auth orchestration for Teamcenter AWC login/logout flows.

    Delegates the actual SOA payload shape to the request models in
    `models/`, keeping this class focused on orchestration rather than
    payload construction.
    """

    def __init__(self, session_manager: SessionManager) -> None:
        self.session_manager = session_manager

    @property
    def _client_config(self) -> dict[str, Any]:
        return self.session_manager.config.get("client", {})

    def login(
        self,
        username: str,
        password: str,
        group: str = "",
        role: str = "",
        locale: str = "en_US",
        descrimator: str | None = None,
    ) -> dict[str, Any]:
        return load_payload(
            "login_payload",
            {
                "username": username,
                "password": password,
                "group": group,
                "role": role,
                "locale": locale,
                "descrimator": descrimator or self._client_config.get("descrimator", "AWC2897"),
            },
            self._client_config,
        )

    def logout(self) -> dict[str, Any]:
        return load_payload("logout_payload", client_config=self._client_config)
