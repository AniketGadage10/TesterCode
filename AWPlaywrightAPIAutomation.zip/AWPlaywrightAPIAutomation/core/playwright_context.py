from __future__ import annotations

from typing import Any

from playwright.sync_api import APIRequestContext, PlaywrightContextManager, sync_playwright


class PlaywrightContext:
    """Wrapper around Playwright API request context."""

    _instance: "PlaywrightContext | None" = None

    def __init__(self, base_url: str):
        self.base_url = base_url
        self._request_context: APIRequestContext | None = None
        self._playwright_manager: PlaywrightContextManager | None = None

    @classmethod
    def get_instance(cls, base_url: str) -> "PlaywrightContext":
        if cls._instance is None:
            cls._instance = cls(base_url)
        return cls._instance

    def create_context(self) -> APIRequestContext:
        if self._request_context is None:
            self._playwright_manager = sync_playwright().start()
            self._request_context = self._playwright_manager.request.new_context(base_url=self.base_url)
        return self._request_context

    def close(self) -> None:
        if self._request_context is not None:
            self._request_context.dispose()
            self._request_context = None
        if self._playwright_manager is not None:
            self._playwright_manager.stop()
            self._playwright_manager = None
