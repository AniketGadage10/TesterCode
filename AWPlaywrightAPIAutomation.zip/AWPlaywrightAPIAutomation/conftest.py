from __future__ import annotations

import re
import socket
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterator
from urllib.parse import urlparse

import pytest
from dotenv import load_dotenv

from config import get_config
from core.api_client import APIClient
from core.auth_manager import AuthManager
from core.session_manager import SessionManager
from services.folder_service import FolderService
from services.item_service import ItemService
from services.login_service import LoginService
from services.logout_service import LogoutService
from services.common_service import CommonService
from services.session_info_service import SessionInfoService
from services.workflow_service import WorkflowService
from utilities.logger import get_logger, create_logger, set_correlation_id

load_dotenv(Path(__file__).parent / ".env")


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:  # noqa: ARG001
    """Auto-tag every collected test with the 'api' marker so `-m api` always
    selects the full suite, without every test file needing the decorator.
    """
    for item in items:
        if "api" not in {marker.name for marker in item.iter_markers()}:
            item.add_marker(pytest.mark.api)


@pytest.fixture(autouse=True)
def _correlation_id(request: pytest.FixtureRequest) -> Iterator[None]:
    """Tag every log line emitted during a test with that test's node id,
    making it trivial to grep logs for a single test's activity.
    """
    set_correlation_id(request.node.name)
    yield
    set_correlation_id("-")


def _is_base_url_resolvable(base_url: str) -> bool:
    parsed = urlparse(base_url)
    hostname = parsed.hostname
    if not hostname:
        return False
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
        return True
    except OSError:
        return False


@pytest.fixture(autouse=True)
def _skip_unavailable_server_tests(request: pytest.FixtureRequest, config: dict[str, Any]) -> Iterator[None]:
    if request.node.get_closest_marker("requires_server") is not None:
        base_url = config.get("base_url", "")
        if not _is_base_url_resolvable(base_url):
            pytest.skip(f"Skipping server-dependent test because base URL host is not resolvable: {base_url}")
    yield


@pytest.fixture(scope="session")
def config() -> dict[str, Any]:
    return get_config()


@pytest.fixture
def logger(request: pytest.FixtureRequest, config: dict[str, Any]) -> Any:
    test_name = re.sub(r"[^A-Za-z0-9._-]+", "_", request.node.name)
    log_file_config = config.get("logging", {}).get("log_file", "logs/framework.log")
    log_dir = Path(log_file_config).parent if isinstance(log_file_config, str) else Path("logs")
    log_path = log_dir / f"{test_name}.log"
    return get_logger(f"framework-{test_name}", config.get("logging", {}).get("level", "INFO"), str(log_path))


@pytest.fixture
def logger_factory(request: pytest.FixtureRequest, config: dict[str, Any]):
    """Factory fixture to create a logger plus an optional capture list.

    Usage in tests:
        logger, records = logger_factory(name="my-test", capture_list=[])
        # pass `logger` into services/clients, then inspect `records` after actions
    """
    test_name = re.sub(r"[^A-Za-z0-9._-]+", "_", request.node.name)
    log_file_config = config.get("logging", {}).get("log_file", "logs/framework.log")
    log_dir = Path(log_file_config).parent if isinstance(log_file_config, str) else Path("logs")

    def _factory(name: str | None = None, level: str | None = None, log_file: str | None = None, capture_list: list | None = None):
        logger_name = name or f"framework-{test_name}"
        lvl = level or config.get("logging", {}).get("level", "INFO")
        resolved_log_file = log_file or str(log_dir / f"{test_name}.log")
        return create_logger(name=logger_name, level=lvl, log_file=resolved_log_file, capture_list=capture_list)

    return _factory


@pytest.fixture
def session_manager(config: dict[str, Any]) -> Iterator[SessionManager]:
    """A fresh SessionManager per test. The singleton is reset before and
    after so parallel/sequential test runs never leak cookies or CSRF state.
    """
    SessionManager.reset()
    manager = SessionManager.get_instance(config=config)
    yield manager
    manager.close()


# Automatic per-test login/logout fixture. Tests that should opt out can use
# `@pytest.mark.no_auto_auth`.
@pytest.fixture
def api_client(session_manager: SessionManager) -> APIClient:
    return APIClient(session_manager=session_manager)


@pytest.fixture
def auth_manager(session_manager: SessionManager) -> AuthManager:
    return AuthManager(session_manager)


@pytest.fixture
def login_service(api_client: APIClient, auth_manager: AuthManager, session_manager: SessionManager) -> LoginService:
    return LoginService(api_client=api_client, auth_manager=auth_manager, session_manager=session_manager)


@pytest.fixture
def logout_service(api_client: APIClient, auth_manager: AuthManager, session_manager: SessionManager) -> LogoutService:
    return LogoutService(api_client=api_client, auth_manager=auth_manager, session_manager=session_manager)


@pytest.fixture
def session_info_service(api_client: APIClient, session_manager: SessionManager) -> SessionInfoService:
    return SessionInfoService(api_client=api_client, session_manager=session_manager)


@pytest.fixture
def folder_service(api_client: APIClient, session_manager: SessionManager) -> FolderService:
    return FolderService(api_client=api_client, session_manager=session_manager)


@pytest.fixture
def item_service(api_client: APIClient, session_manager: SessionManager) -> ItemService:
    return ItemService(api_client=api_client, session_manager=session_manager)

@pytest.fixture
def common_service(api_client: APIClient, session_manager: SessionManager) -> CommonService:
    return CommonService(api_client=api_client, session_manager=session_manager)

@pytest.fixture
def common_service(api_client: APIClient, session_manager: SessionManager) -> CommonService:
    return CommonService(api_client=api_client, session_manager=session_manager)

@pytest.fixture
def workflow_service(api_client: APIClient, session_manager: SessionManager) -> WorkflowService:
    return WorkflowService(api_client=api_client, session_manager=session_manager)

@pytest.fixture
def test_user(config: dict[str, Any]) -> dict[str, Any]:
    """The primary configured user (config/users, overridable via AWC_* env vars)."""
    users = config.get("users", [])
    if not users:
        raise RuntimeError("No user configuration found. Set users in config/<env>.yaml or AWC_USERNAME/AWC_PASSWORD.")
    return users[0]


@pytest.fixture
def api_services(
    login_service: LoginService,
    logout_service: LogoutService,
    session_info_service: SessionInfoService,
    folder_service: FolderService,
    item_service: ItemService,
    common_service: CommonService,
    workflow_service: WorkflowService,
    test_user: dict[str, Any],
) -> SimpleNamespace:
    """Group commonly used API services into a single fixture for concise tests."""
    return SimpleNamespace(
        login_service=login_service,
        logout_service=logout_service,
        session_info_service=session_info_service,
        folder_service=folder_service,
        item_service=item_service,
        test_user=test_user,
        common_service=common_service,
        workflow_service=workflow_service
    )


@pytest.fixture
def authenticated_session(login_service: LoginService, logout_service: LogoutService, test_user: dict[str, Any]) -> Iterator[dict[str, Any]]:
    """Logs in with the primary configured user and logs out after the test.

    If the test performs its own logout, the fixture will not repeat it.
    """
    response = login_service.login()
    assert response.is_success, f"Login failed with status {response.status}: {response.text()}"

    session = {"login_response": response, "user": test_user, "logout_called": False}
    yield session

    if not session["logout_called"]:
        logout_service.logout()
